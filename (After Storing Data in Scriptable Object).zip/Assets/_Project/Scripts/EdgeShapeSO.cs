using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Splines;
#if UNITY_EDITOR
using Unity.EditorCoroutines.Editor;
#endif

[CreateAssetMenu(menuName = "Puzzle Data/Edge Profile",fileName = "Edge Profile Info")]
public class EdgeShapeSO : ScriptableObject
{
    public SplineContainer knobProfile;
    public float xLength;
    public Material puzzleMaterial;

    private float scaleFactor;
    private List<float3> flatCornerPositions;
    private Dictionary<string, List<float3>> profileVertices;

    #region Mesh Data

    [Space(40), Header("Mesh Data For All Possible Puzzle Piece Combination")] 
    [SerializeField] private List<MeshData> allPossibleMeshCacheList;

    private Dictionary<string, MeshData> meshCacheDictionary;
    #endregion
    
    

    public float3 BottomLeft => flatCornerPositions[0];
    public float3 TopLeft => flatCornerPositions[1];
    public float3 TopRight => flatCornerPositions[2];
    public float3 BottomRight => flatCornerPositions[3];

    private static readonly int curveResolution = 40;

    
    public void Init()
    {
        meshCacheDictionary = new Dictionary<string, MeshData>();
        foreach (MeshData data in allPossibleMeshCacheList)
        {
            meshCacheDictionary[data.edgeProfile] = data;
        }
        // SetScaleFactor(cellSize);
        //
        // float halfCellSize = cellSize * 0.5f;
        // flatCornerPositions = new List<float3>
        // {
        //     new (-halfCellSize, -halfCellSize, 0),
        //     new (-halfCellSize, halfCellSize, 0),
        //     new (halfCellSize, halfCellSize, 0),
        //     new (halfCellSize, -halfCellSize, 0)
        // };
        //
        // profileVertices = new Dictionary<string, List<float3>>();
    }

    public void UpdatePuzzleMaterial(Texture2D puzzleTexture, int width, int height)
    {
        puzzleMaterial.mainTexture = puzzleTexture;
        puzzleMaterial.SetFloat("_Width",width);
        puzzleMaterial.SetFloat("_Height",height);
    }

    public MeshData GetMeshData(string key)
    {
        return meshCacheDictionary[key];
    }

    public void EvaluateAllPossibleSplinesCombinationOnMainThread()
    {
        float3 scale = new float3(scaleFactor,scaleFactor,1);
        float3 negativeScale = new float3(scaleFactor, -scaleFactor, 1);
        
        //Left Side
        float3 translation = flatCornerPositions[0];
        quaternion rotation = quaternion.EulerXYZ(0,0,math.radians(90));
        profileVertices.Add(EdgeName.LeftKnob, GetSplineVertices(float4x4.TRS(translation,rotation,scale)));
        profileVertices.Add(EdgeName.LeftSocket, GetSplineVertices(float4x4.TRS(translation,rotation,negativeScale)));
        
        //Top Side
        translation = flatCornerPositions[1];
        rotation = quaternion.identity;
        profileVertices.Add(EdgeName.TopKnob, GetSplineVertices(float4x4.TRS(translation,rotation,scale)));
        profileVertices.Add(EdgeName.TopSocket, GetSplineVertices(float4x4.TRS(translation,rotation,negativeScale)));
        
        //Right Side
        translation = flatCornerPositions[2];
        rotation = quaternion.EulerXYZ(0,0,math.radians(270));
        profileVertices.Add(EdgeName.RightKnob, GetSplineVertices(float4x4.TRS(translation,rotation,scale)));
        profileVertices.Add(EdgeName.RightSocket, GetSplineVertices(float4x4.TRS(translation,rotation,negativeScale)));
        
        //Bottom Side
        translation = flatCornerPositions[3];
        rotation = quaternion.EulerXYZ(0,0,math.radians(180));
        profileVertices.Add(EdgeName.BottomKnob, GetSplineVertices(float4x4.TRS(translation,rotation,scale)));
        profileVertices.Add(EdgeName.BottomSocket, GetSplineVertices(float4x4.TRS(translation,rotation,negativeScale)));
    }
    
    private List<float3> GetSplineVertices(float4x4 trsMatrix)
    {
        NativeSpline nativeSpline = new NativeSpline(knobProfile.Spline, trsMatrix);
        
        List<float3> splinePoints = new List<float3>(curveResolution);
        for (int i = 0; i < curveResolution; i ++)
        {
            float3 p = nativeSpline.EvaluatePosition((float)i/ (curveResolution));
            splinePoints.Add(p);
        }
        nativeSpline.Dispose();
        
        return splinePoints;
    }

    public List<float3> GetEvaluatedVertices(string key)
    {
        profileVertices.TryGetValue(key, out List<float3> value);
        return value;
    }
    
#if UNITY_EDITOR
    [Space(60), Header("Editor Only Data")] 
    [SerializeField] private float cellSize;
    [SerializeField] private PuzzlePiece puzzlePrefab;
    [SerializeField] private bool generateGameObjects;
    
    private EditorCoroutine meshDataCalculationCoroutine;
    
    [ContextMenu("Calculate All Possible MeshData")]
    public void CalculateAllPossibleMeshData()
    {
        if (meshDataCalculationCoroutine != null)
        {
            Debug.LogError("Editor Coroutine is Still Running");
            return;
        }
        meshDataCalculationCoroutine = EditorCoroutineUtility.StartCoroutine(CalculateMeshData(), this);
    }

    private IEnumerator CalculateMeshData()
    {
        SetUpScriptableEditorOnly(cellSize);
        
        yield return null;
        
        //here length is 81 because there are 4 edges each with 3 different combination
        //so 3^4 possible combinations
        for (int i = 0; i < 81; i++)
        {
            string ternaryNum = ConvertDecimalToTernary(i);

            MeshData generatedData = EarClipping.GenerateMeshDataEditorOnly(this, ternaryNum);
            allPossibleMeshCacheList.Add(generatedData);
            yield return null;
        }

        if (generateGameObjects)
        {
            GameObject parentObject = new GameObject("Parent")
            {
                transform =
                {
                    position = Vector3.zero
                }
            };
            float x = 0;
            float y = 0;
            for (int i = 0; i < allPossibleMeshCacheList.Count; i++)
            {
                x = i % 9;
                var piece = Instantiate(puzzlePrefab, parentObject.transform);
                if (i % 9 == 0)
                {
                    y += 3;
                }
                piece.transform.position = new Vector3(x * 3, y, 0);
                piece.SetMeshData(allPossibleMeshCacheList[i]);
                yield return null;
            }
        }

        
        meshDataCalculationCoroutine = null;
    }

    private string ConvertDecimalToTernary(int num)
    {
        string ternary = string.Empty;
        while (num > 0)
        {
            ternary = (num % 3) + ternary;
            num /= 3;
        }
        
        return ternary.PadLeft(4,'0');    
    }
    
    private void SetUpScriptableEditorOnly(float cellSize)
    {
        allPossibleMeshCacheList.Clear();
        scaleFactor = cellSize / xLength;
        
        float halfCellSize = cellSize * 0.5f;
        flatCornerPositions = new List<float3>
        {
            new (-halfCellSize, -halfCellSize, 0),
            new (-halfCellSize, halfCellSize, 0),
            new (halfCellSize, halfCellSize, 0),
            new (halfCellSize, -halfCellSize, 0)
        };

        profileVertices = new Dictionary<string, List<float3>>();
        EvaluateAllPossibleSplinesCombinationOnMainThread();
    }
    
#endif
}


public static class EdgeName
{
    public static readonly string LeftKnob = "LeftKnob";
    public static readonly string LeftSocket = "LeftSocket";
    
    public static readonly string TopKnob = "TopKnob";
    public static readonly string TopSocket = "TopSocket";
    
    public static readonly string RightKnob = "RightKnob";
    public static readonly string RightSocket = "RightSocket";
    
    public static readonly string BottomKnob = "BottomKnob";
    public static readonly string BottomSocket = "BottomSocket";
}

public enum EdgeType
{
    Flat,
    Knob,
    Socket
}

[Serializable]
public struct MeshData
{
    public string edgeProfile;
    public Vector3[] vertices;
    public int[] triangles;
    public Vector2[] uvs;
}