public interface IGridObject
{ 
    int X { get; set; }
    int Y { get; set; }
}
